# The LLD interview playbook (distilled from the Amazon Locker video)

Source: Hello Interview, "Low-Level Design Interview: Design Amazon Locker w/ a Ex-Meta Staff Engineer" (Evan King, 50:55, https://www.youtube.com/watch?v=s6nGkoGJhXk), its editor file (`amazon_locker_original.py`, from https://pastebin.com/uMD5XNU7), and Hello Interview's "LLD in a Hurry" pages. Timestamps such as `[04:20]` point into `amazon_locker_transcript.txt`.

Every set of notes this skill produces must follow these rules. Each rule names the screenshot that shows it in the original video.

---

## 0. The delivery framework (5 steps, ~35 min of a 45-min interview)

![framework](screenshots/00-delivery-framework.png)

| # | Step | Time | Output on the "whiteboard" (one editor file) |
|---|------|------|----------------------------------------------|
| 1 | Requirements | ~5 min | Clarifying questions → numbered requirements → **Out of scope** list |
| 2 | Entities & relationships | ~3 min | List of nouns, pruned to the real entities |
| 3 | Class design | ~10–15 min | For each class: `- state` and `+ behavior()` signatures |
| 4 | Implementation | ~10 min | Pseudo-code for the interesting methods: **Core logic** + **Edge cases** first, then code |
| 5 | Extensibility | ~5 min, if time/level | Interviewer "what if…" questions → smallest change to the design |

The framework exists to "keep you focused and on track" and to keep you from running out of time [01:05]. If the interviewer pulls you off it, follow them and steer back when you can.

**Everything is typed into one file** (in the video, `amazon-locker.py`). The order is: the prompt as a docstring, then the questions, requirements, out of scope and entities, then class sketches, `# Implementation`, and `# Extensions`. The notes this skill produces include an editor file in exactly this shape. See `amazon_locker_original.py` (raw) and `example-amazon-locker/amazon_locker.py` (annotated).

---

## 1. Requirements: "problem analysis" is graded

![prompt](screenshots/01-vague-prompt.png)

- The prompt is **vague on purpose**. Do not start coding. The interviewer is grading "problem analysis", your ability to turn the prompt into a clear set of requirements [03:47–04:20].
- Ask questions in **three categories** [04:53] (Hello Interview's written guide adds a fourth, "rules & completion"; use it for games or any workflow with an end state):
  1. **Primary capabilities**: what must the system do, and with which variants (sizes, types, roles)?
  2. **Error handling**: what happens when things go wrong (full, invalid, expired, duplicate, never completed)?
  3. **Scope boundaries**: where does this system start and stop? Which neighbouring systems are external?
  4. *(optional)* **Rules & completion**: what are the win/end conditions, turn order and invariants?

![questions](screenshots/02-clarifying-questions-3-categories.png)

- Write each question down and record the interviewer's answer. In the Locker video:
  - Sizes? Yes: small, medium and large.
  - How does the code reach the user? Out of scope; just return it.
  - Can one customer have many packages? Yes, each with its own token.
  - Do codes expire? After 7 days, then staff remove the package.
  - Every compartment of that size is full? Throw an error.
  - Scope? Only from the driver arriving to the customer pickup.
- Converge on a short **numbered requirement list**. Each requirement has sub-bullets for the system's reaction and its error. Then add an explicit **Out of scope** list.

![requirements](screenshots/03-final-requirements-and-out-of-scope.png)

- "Everything not mentioned here is implicitly out of scope." [07:38]. From here on you build exactly this list and nothing else.
- In a real interview, questions and requirements are written interleaved, a little at a time [07:38].

## 2. Entities: nouns, then prune

![nouns](screenshots/04-entities-all-nouns.png) ![pruned](screenshots/05-entities-pruned.png)

- Underline every **noun** in the requirements and list them all first [08:10].
- Then test each one: **does our system need to remember state or enforce rules for it?**
  - **Actors outside the system** (driver, customer) → drop them. We never store their state; they just call our API [08:43–09:16].
  - **Things owned by another system** (Package) → drop them. Keep only the attribute we need (`size`) as a **method parameter**. "Most candidates add a package here." [09:16–10:22]
  - **The orchestrator** (Locker) → keep it. It is the entry point, it scans compartments, and it ties everything together [10:22].
  - **Physical or stateful parts** (Compartment) → keep them [10:22].
  - **"Isn't it just a string?"** (AccessToken) → keep it if it carries **its own rules**. Here it is a bearer token with an expiry that grants the right to one compartment [10:54–11:26].
- It is fine to get this wrong at first and come back and edit the list later. Doing that is "even promoted" [11:58].

## 3. Class design: top-down, state then behavior, derived from requirements

![locker state](screenshots/06-class-design-locker-state.png) ![complete](screenshots/07-class-design-complete.png)

- Start with the **orchestrator** and move **down** to the classes it depends on. High-level operations reveal what the lower classes must provide [12:30].
- For each class, scan the requirements twice:
  - **State** = "the things you need to remember to enforce the requirements" [02:10, 13:02].
  - **Behavior** = what the class must be able to do, i.e. its public interface. Each public method maps to a **user action** in the requirements: deposit → `depositPackage(size)`, retrieve → `pickup(code)`, staff → `openExpiredCompartments()` [15:48–16:54].
- Notation used on the whiteboard:
  ```
  class Locker:
      - compartments: Compartment[]
      - accessTokensMapping: Map<string, AccessToken>
      + depositPackage(size) -> string | error
      + pickup(code: string) -> void | error
  ```
- **Choose data structures for clarity first, Big-O second.** Use `Map<code, token>` "not really because of the O(1)… just because the intent becomes super clear" [14:41]. Candidates trained on LeetCode over-optimise; when n is small (under hundreds of thousands), think about readability [15:14].
- **Information Expert / encapsulation:** the Compartment owns its own physical state (`markOccupied`, `markFree`, `open`). A map of occupancy kept on the Locker would be O(1), but occupancy is a *physical* property of the compartment, not a *relationship*, so it lives on Compartment [20:44–21:16].
  - Rule: **physical or intrinsic state lives on the entity; relationships between entities live in the orchestrator.**
- Hardware hooks such as `open()` are declared, not implemented [20:12].

## 4. Implementation: Core logic → Edge cases → code, one method at a time

![deposit](screenshots/08-impl-deposit-core-logic-edge-cases.png)

- Implement only the **interesting** methods, usually on the orchestrator. Getters, setters and `isExpired` (a comparison with now) are skipped [22:57]. Senior candidates propose which methods to implement; for juniors the interviewer usually picks [21:16].
- Most interviews (~65–70%) want **pseudo-code**; about 30–35% want a real language [21:48]. Ask which one.
- For **each** method, write a docstring with two numbered lists before writing any code [22:24]:
  ```
  """
  Core logic:
  1. …step that maps 1:1 to a line of code…
  Edge cases:
  1. <condition> -> throw / return null
  """
  ```
  Then write the code so each core-logic step becomes one or two lines.
- Walk the core-logic steps **one by one** asking "what can go wrong here?" [24:38–25:43], and say out loud which failures you scope away (mechanical failure, out of memory).
- Use **private helpers** named after a core-logic step (`getAvailableCompartment`, `generateAccessToken`), then ask the interviewer: "Do you want me to implement those?" [27:58–28:30].

![helper](screenshots/09-impl-private-helper.png)

- **Don't repeat expressions.** Store `code = accessToken.getCode()` once [27:26].
- **Language-dependent behaviour gets stated as an assumption**, e.g. "a map miss returns null in my pseudo-code" [34:37].
- **Validate inputs at the boundary first**: an empty code is invalid, an unknown code is invalid, an expired code gets a *distinct* error [33:29–35:10].

![pickup plan](screenshots/10-impl-pickup-plan.png) ![pickup code](screenshots/11-impl-pickup-code.png)

- **Physical simplifications get confirmed with the interviewer**, e.g. "doors auto-close after ~30 s, and the user takes the package." Real systems use sensors, which you can save for extensibility [31:52–32:25].
- **Product trade-offs are decided with the interviewer and recorded in the code.** For example, should expired tokens be removed from the map? No: keep them so a late user gets "expired" instead of "invalid". Do the memory maths out loud (50 compartments × 100 days ≈ 5k entries, which is fine) and mention a later cleanup loop [36:51–39:07].
  - Write the decision into the core logic: `6. remove from map??? decision: no`.

![open expired](screenshots/12-impl-open-expired-with-decision.png)

- Check **idempotency and empty input** for bulk operations (empty map, everything expired, called twice) [39:39].

## 5. Extensibility: the smallest change, explained more than coded

![ext list](screenshots/13-extensibility-questions.png)

- Intern, junior and mid-level interviews may end before this step. Seniors should expect several "what if" questions [40:48]. Often you **describe** the change instead of coding it [43:33].
- The canonical patterns, which reuse across almost every LLD problem:

| Follow-up shape | Pattern | Locker example |
|---|---|---|
| "Fall back to a bigger/other option" | Add **one outer loop** over an ordered enum list, starting from the requested index | Small package tries small → medium → large [41:53–43:33] |
| "Broken / maintenance / a third state" | **Boolean → enum** once there are more than 2 states; the entity owns it (Information Expert) | `CompartmentStatus {AVAILABLE, OCCUPIED, OUT_OF_SERVICE}` [44:06–45:42] |
| "Make sure X really happened before Y" | **Two-phase commit**: reserve → confirm (+ cancel/timeout); add a RESERVED state | `reserveCompartment` / `confirmDeposit` / `cancelReservation` [45:42–49:32] |

![fallback](screenshots/14-ext-size-fallback-loop.png) ![enum](screenshots/15-ext-status-enum.png) ![2pc](screenshots/16-ext-two-phase-commit.png)

Other patterns that come up often in other problems (not in this video; use them where they fit): **Strategy** (pluggable pricing or assignment policy), **Observer** (notify on state change), **State** (behaviour varies by lifecycle state), **Factory** (creating variants), **Singleton** (rarely; avoid unless asked), and **concurrency** (locks or atomic reservation when two callers race for one resource).

---

## Principles the design is judged on (closing summary [50:04])

- **Information Expert**: the class that owns the data enforces the rules (Compartment knows its own status).
- **Separation of concerns**: an orchestrator (Locker), an access-control object (AccessToken), and physical state (Compartment).
- **KISS / no premature optimisation**: linear scans are fine because n ≈ 50–100. Size-indexed queues were rejected because the state is duplicated and goes out of sync.
- **YAGNI**: model only what the agreed requirements need. Package is not an entity.
- **Enums over booleans** once there are more than 2 states. **Composition over inheritance.** **Tell, don't ask.** **Law of Demeter.**
- **Explicit errors with specific messages** for each failure the requirements name.

## The interviewer's rubric

| Dimension | What earns credit |
|---|---|
| Problem analysis | Asking the right questions in the 3 categories; a crisp requirement list with an out-of-scope list |
| Class design | Right entities (not too many), clear ownership, signatures derived from requirements |
| Code quality | Encapsulation, helpers that mirror the core-logic steps, no duplication, readable over clever |
| Extensibility | Small follow-ups absorbed without a rewrite; the change lands in exactly one place |
| Communication | Thinking aloud, stating assumptions, checking with the interviewer at each decision |

**What each level is expected to show** (from the Locker write-up):
- **Junior**: core entities, a working happy path, awareness of edge cases. Hints are OK.
- **Mid**: reaches the right class model by reasoning, separates concerns, handles invalid, expired and full cases, and covers one extension unaided.
- **Senior and above**: drives the design with minimal prompting, applies Information Expert, discusses trade-offs (where occupancy lives, lazy cleanup, when Package would need to be an entity), and raises follow-ups before being asked.

## Common mistakes the video calls out

1. Coding straight away from the vague prompt.
2. Modelling every noun: actors (User, Driver) and externally-owned data (Package).
3. Treating a rule-carrying concept as "just a string" (the AccessToken).
4. O(1) everything, at the cost of duplicated state and clarity.
5. Putting physical state in the orchestrator instead of on the entity.
6. Silently assuming hardware behaviour instead of stating the simplification.
7. One generic error for every failure. The requirements asked for *specific* errors, e.g. expired vs invalid.
8. Deleting data that is still needed for good error messages, without discussing the trade-off.
9. Trusting that a physical step happened (the deposit) without a confirm step.
