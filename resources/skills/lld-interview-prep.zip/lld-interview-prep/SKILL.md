---
name: lld-interview-prep
description: Turn any low-level design (LLD / object-oriented design / machine-coding) topic, or an LLD YouTube video, into an interview-prep case study that follows the Hello Interview delivery framework from Evan King's "Design Amazon Locker" video. The framework is Requirements via 3 question categories → noun-pruned Entities → top-down Class Design → Implementation (Core logic + Edge cases before code) → Extensibility. Every run produces one annotated solution file (talking points, tricky spots, best approach), 5 workbooks (requirements; entities + class design; guided implementation; blank implementation; extensibility), an AI-gradable answer key for each, a rulebook for filling them in and evaluating them, and runnable Java code in two versions (Phase 1 = core requirements, Phase 2 = the important extensions) with stubbed implementations of the out-of-scope interfaces and self-checking Main classes. Also use it to EVALUATE a filled-in workbook. Use when the user names an LLD topic (Parking Lot, Elevator, Vending Machine, Connect Four, Rate Limiter, BookMyShow, Splitwise, ...) or gives an LLD video and asks for interview prep, notes, a workbook, practice, "like the Amazon Locker one", or asks to grade/evaluate an attempt.
---

# LLD interview prep: annotated solution + workbooks + answer keys + Java code

The finished example is `reference/example-amazon-locker/`. Every case study must have **the same files, sections, markers, item-ID scheme and point totals**. Open it before you start, and copy its structure, not its content.

The finished example of the **code** is `reference/example-code-notification-router/` (two phases, built from the notification-router design). Copy its layout, conventions and Main style, not its content.

## Two modes

- **Create** (default): build a case study for a topic or video → the Create workflow below.
- **Evaluate**: the user asks to grade an attempt (e.g. "evaluate attempts/2026-11-10/03_*.py") → follow the case study's `RULEBOOK.md` §3–4 exactly, using its `answer-key/`. Don't use this file's create steps.

## Read first (create mode)

1. `reference/framework.md`: the rules of each step, the rubric, the principles, the common mistakes, the reusable extensibility patterns. Each rule cites a screenshot and timestamp.
2. `reference/example-amazon-locker/`: **the target output.** Read `amazon_locker.py`, one workbook and its key, and `RULEBOOK.md`.
3. `reference/amazon_locker_original.py`: the raw editor file from the video, with no annotations. It shows what the candidate actually types.
4. `reference/screenshots/`: open at least `00`, `03`, `07`, `08`, `12` to see how the editor looks at each step.
5. `reference/amazon_locker_transcript.txt`: grep it when you need the exact reasoning behind a rule.

## Inputs

- **Topic** (required), or a **YouTube URL** of an LLD walkthrough.
  - If you're given a URL: download it to `<CaseFolder>/source/` (yt-dlp at 1080p plus English captions → a timestamped transcript; on this machine use an `SSL_CERT_FILE` built from the keychains plus `--compat-options no-certifi --js-runtimes node`, and update yt-dlp first). Look in the video description for a linked editor file or code and save it to `source/reference/`. Grab frames with ffmpeg into `screenshots/`, named `NN-<step>-<what>.png`, about 1–3 per framework step. The video's own design is the base. Add annotations where it's weak, and fix and flag real bugs (as TRICKY #6 does for Amazon Locker).
  - With a topic only: design it yourself with the framework, and copy the framework screenshot `00` into `screenshots/`.
- **Level** (default *senior*) and **language** (default *pseudo-code*). State the defaults in one line; ask only if the topic is ambiguous.

## Output: `/Users/yash/Documents/DDIA2/LLD-Notes/case-studies/<topic-kebab>/`

Use a kebab-case folder name to match the existing case studies (bookmyshow, parking-lot, ...). Then add the new case study to the tree and to the "Case studies" list in `/Users/yash/Documents/DDIA2/LLD-Notes/README.md`.

```
<topic_snake>.py                      annotated solution (one file, whole interview)
README.md                             index plus "the one non-obvious thing"
RULEBOOK.md                           from templates/RULEBOOK.md (fill <topic_snake>, <TopicCamel>)
workbook/01_requirements.py
workbook/02_entities_and_class_design.py
workbook/03_implementation_guided.py
workbook/04_implementation_blank.py
workbook/05_extensibility.py
answer-key/0N_<same name>.key.md      one per workbook, 100 pts each
attempts/                             empty; the student's dated attempts go here
screenshots/                          frames (video) or at least 00-delivery-framework.png
code/README.md                        how to run, package tree, per-phase class and extension tables
code/Phase-1-Core-Requirements/       run.sh + src/<topicnospaces>/... : the base requirements only
code/Phase-2-Extensions/              run.sh + src/<topicnospaces>/... : Phase 1 + the important follow-ups
source/                               only for video runs: video, transcript, original code
```

## Create workflow

### Step 1: Design the solution (framework.md §1–5)
- **Prompt:** one deliberately vague sentence.
- **Requirements:** questions in the 3 categories (add "rules & completion" for games), each with the interviewer's answer → 4–6 numbered requirements (actor + action + input, with sub-bullets for reaction and error) → out of scope.
- **Entities:** all nouns → keep/drop with a reason (drop external actors; data owned elsewhere becomes a parameter; keep "just a string" when it carries rules). Aim for 3–5 entities plus enums.
- **Class design:** top-down from the orchestrator. Every member is traced to a requirement. Decide where each piece of state lives (physical/intrinsic → the entity; relationships → the orchestrator) and choose collections for clarity.
- **Implementation:** the 3–5 interesting methods (any method that throws a requirement-named error counts). Each has a `Core logic:` / `Edge cases:` docstring before its code, at least one `??? decision:` product trade-off, stated assumptions, and a verification trace.
- **Hunt for a real bug or subtle trap** in the obvious design: state that's reused, idempotency, check-then-act, a stale reference. If you find one, it becomes a ⚠️ TRICKY item and a trace question in workbook 03.
- **Extensibility:** the 3 most-asked follow-ups, coded, plus 2–3 more (security/abuse, concurrency only when the scope allows concurrent callers, scale-out). For each, give the pattern + where it lands + the spoken answer.

### Step 2: Write `<topic_snake>.py` (the annotated solution)
Copy the layout of `example-amazon-locker/amazon_locker.py` exactly:
- A header with the **LEGEND** (`# 💬 SAY:` · `# ⚠️ TRICKY:` · `# ✅ BEST:` · `# 🎯 GRADED:` · `⏱` · `📸`) and the 5-step framework with time budgets.
- The five steps in order, each opened by a banner with ⏱ and 📸 refs. The editor content (prompt, questions → `-> answer`, requirements, out of scope, entities table, class sketches, `# Implementation`, `# Extensions`) appears as the candidate would type it. Annotations sit right next to the line they explain.
- At least 2 💬 SAY per step, a ✅ BEST at every design decision (with the rejected alternatives: BAD / GOOD / GREAT where relevant), a ⚠️ TRICKY at every place candidates lose points, and 🎯 GRADED linking moments to the rubric.
- If the obvious version has a bug: show `---- AS WRITTEN ----`, explain the bug, then `---- BEST VERSION ----`.
- End with **VERIFICATION TRACE**, **MORE FOLLOW-UPS SENIORS GET**, and a **60-SECOND RECAP**.

### Step 3: Write the 5 workbooks
Mirror the example workbooks. These rules are what make them gradable:
- Each workbook starts with a header (title, **time box**, "Closed book", "Copy into attempts/<date>/") and **GIVEN**: the canonical answer of the previous step, so mistakes don't cascade. (01 gives only the prompt. 02 gives the requirements. 03 and 04 give the class design. 05 gives the finished base design.)
- Every blank is `TODO` and every question carries its **answer-key ID in brackets**, e.g. `# A3 [Q3].`, `# [C1] class …`, `# YOUR CODE [I3-1]`, `# X2.`.
- **01:** categories, questions per category with the expected answer, requirements, out of scope, a 3-question talk track.
- **02:** a noun list, keep/drop table, the dropped-noun-attribute question, the "just a string" question, enums, then class sketches (top-down, with requirement comments), then 5 design-decision questions.
- **03:** for each interesting method, the docstring is **pre-filled** (core logic and edge cases) and the body is `TODO`. Then 2–3 questions: the physical/language assumptions, and a **trace question that exposes the trap** you found.
- **04:** the same methods with **empty docstrings and bodies**. Then the trade-off, a safety/idempotency proof, and a 4-line trace. Tell the student to do it on a different day from 03.
- **05:** 5–6 follow-ups, each with `Pattern / Lands in / Say / Code`.

### Step 4: Write the 5 answer keys
Mirror the example keys. Each key:
- totals **exactly 100 points**. Check the arithmetic: item maxima add to 100, and sub-check tables add to each item's maximum.
- uses the workbook's item IDs. For each item: **Must** criteria with points, **Partial** rules, **Accept** variants, **Red flags** as deductions, optional **Bonus** with a cap, and a **model answer** (code for implementation items).
- has implementation keys that check logic and order (null-check before mutation, distinct errors, no mutation on error paths), not syntax.
- ends with **Level calibration** (score bands → junior/mid/senior), plus any cap rule (e.g. "without spotting the trap, cap at mid").
- key 04 reuses key 03's code tables, scaled, and adds points for the student's own docstrings. It also tells the evaluator to report the 03→04 delta.

### Step 5: RULEBOOK.md + README.md
- `RULEBOOK.md` = `templates/RULEBOOK.md` with the placeholders filled. Don't change the scoring procedure or the report format.
- `README.md` follows the example: source link, a file table (include a `code/` row: "Runnable Java, Phase 1 core + Phase 2 extensions"), the study loop, and **the one non-obvious thing** (the trap).

### Step 6: Write the Java code, two versions
Always Java (JDK 17+), even though the solution file is pseudo-code. Mirror `reference/example-code-notification-router/` (also `case-studies/rate-limiter/hello-interview-rate-limiter/` in the notes repo).

**Layout.** `code/Phase-1-Core-Requirements/` and `code/Phase-2-Extensions/`, each with:
- `run.sh` (copy the example's: `javac -d out $(find src -name "*.java")` then `java -cp out <pkg>.Main`; `chmod +x`). `out/` is already gitignored.
- `src/<pkg>/` where `<pkg>` is the topic in lowercase with no separators (`notificationrouter`, `amazonlocker`). Split into sub-packages **by role**, only the ones the design needs:
  - `model/`: enums, value objects, entities
  - one package per out-of-scope seam, named for its role (`handler/`, `payment/`, `notifier/`): the interface plus its stub implementations
  - the orchestrator's package (`router/`, `service/`, `system/`) with the orchestrator and the requirement-named exception classes
  - Phase 2 only: one package per extension mechanism (`policy/`, `preference/`, `strategy/`, ...)
  - `Main.java` at the package root

**Class conventions** (the user's explicit preferences):
- Plain classes: `private final` fields, a constructor, getters, `equals`/`hashCode` only when used as a map key or compared. **No Java `record`s.**
- Value objects are immutable and validate themselves in the constructor (`IllegalArgumentException`), so an invalid one can't exist.
- Each requirement-named error from the design gets its own small `RuntimeException` subclass (e.g. `NoPreferredChannelException`), thrown from the same place as in the design.
- The orchestrator fails fast in its constructor on bad config (a missing handler/strategy for an enum value), and keeps defensive copies (`EnumMap`, `List.copyOf`) of maps and lists it's given.
- Validate everything **before** any mutation or side effect; once side effects start, don't throw mid-way, record per-item outcomes.
- Use the **BEST version** from Step 4, never the trap version. Comments only for the why, one line, citing the requirement (`// Req 3`) or extension (`// EXT 2`) where it helps a reader map code to the design.

**Out-of-scope interfaces get real stub classes.** For every interface the design keeps as a seam with implementations out of scope (e.g. `ChannelHandler` → `EmailHandler`, `SmsHandler`, `PushHandler`), write one class per variant named in the design. The external call is stubbed: a one-line comment saying what real code would do (look up X, call provider Y, throw on provider error) and a `System.out.println` of what would be sent. Add the extra variant(s) Phase 2 introduces (e.g. `WhatsAppHandler`). Test doubles (recording / always-failing) stay as nested classes in `Main`, not in the seam package.

**Phase 1: core requirements only.** Exactly the requirements from Step 1, the classes from Step 3, and the methods from Step 4. No extension hooks, no Strategy for two cases (KISS/YAGNI, same as the solution file).

**Phase 2: Phase 1 + the important extensions.** Start from a copy of Phase 1. Code the 3 most-asked follow-ups from Step 5, plus cheap ones the design calls important (e.g. a new enum variant, concurrency via `ConcurrentHashMap` + immutable values read once, when scope allows concurrent callers). Each extension lands where the solution file says it lands. The Phase 1 public API keeps working (add overloads, don't break callers). Here the patterns are earned (Strategy map keyed by enum, promoted value class, plan/result object), so use them. Leave the "more follow-ups" (queues, allow-lists, audit) uncoded and list them in the README.

**`Main` = self-checks**, not a demo script:
- helpers `expect(got, want, label)`, `expectThrows(action, ExceptionClass, label)`, `check(cond, msg)` that throw `IllegalStateException("CHECK FAILED: …")`; print `OK` / `THROWS` lines.
- Phase 1: the solution file's VERIFICATION TRACE line by line, an explicit check that **the trap does not happen** (e.g. "tried exactly once"), input-validation throws, and the bad-config-at-startup check.
- Phase 2: a short re-run of the base trace through the new structure, one method per extension (`ext1…`, `ext2…`), the new bad-config checks.
- Both: a final `demoWithRealHandlers()`-style section that wires the stub implementations (not test doubles) and routes a few cases, then `All checks passed.`

**`code/README.md`** (copy the example): run instructions, the package tree, a Phase 1 `Class | Role` table, a Phase 2 `Extension | Pattern | What changed` table, and a "Not coded" line.

**Run both phases** (`./run.sh`) and fix until both print `All checks passed.` Failed sends may print `[warn]` to stderr; that's expected.

### Step 7: Self-check, then report
- [ ] Same file set and names as the example. Every image path referenced in the files exists.
- [ ] The solution file has every legend marker and all 5 step banners, and each public method maps to a requirement.
- [ ] Every requirement-named error has a specific `throw Error("…")`. No pruned noun comes back as a class.
- [ ] Each workbook has no answer leaking into it (the GIVEN section is only the previous step's output), and every question has a bracketed key ID that exists in its key.
- [ ] Each key adds up to 100 (actually add the numbers), and every workbook ID is scored.
- [ ] The trap appears in three places: a TRICKY in the solution, a trace question in 03, a proof question in 04, and a check in Phase 1 `Main` that asserts it doesn't happen.
- [ ] Both `code/Phase-*/run.sh` print `All checks passed.` No `record`s. Every out-of-scope interface has a stub class per variant. Phase 2 still accepts Phase 1's calls.
Then tell the user the folder path, the entities, the trap, the follow-ups, and which extensions Phase 2 codes, in a few lines.

## Facts you can't source
"Commonly asked at" and "most-asked follow-ups" come from your general knowledge. Write "commonly reported", leave the companies out when unsure, and never invent statistics.

## Style
Keep the voice of a calm senior interviewer coaching you. KISS like the video: linear scans when n is small, no patterns used just to show off, no speculative classes. Don't copy Hello Interview's written breakdowns word for word; write in your own words using the method.
